import requests
from django.contrib.auth import authenticate
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt, csrf_protect

from .models import *
from django.views import View
from django.shortcuts import render, redirect
from .forms import RegisterForm
from django.contrib.auth import login


class HomePageView(View):
    def get(self,request):
        return render(request,"index.html")


class AboutPageView(View):
    def get(self,request):
        return render(request,"about-us.html")


def add_to_cart_view(request):
    products = Product.objects.all()

    if request.method == 'POST':
        # Получаем или создаем корзину
        if request.user.is_authenticated:
            cart, created = Cart.objects.get_or_create(user=request.user)
        else:
            cart, created = Cart.objects.get_or_create(user=None)

        for product in products:
            qty_str = request.POST.get(f'quantity_{product.id}', '0')
            try:
                quantity = int(qty_str)
            except ValueError:
                quantity = 0

            if quantity > 0:
                item, created = CartItem.objects.get_or_create(cart=cart, product=product,
                                                               defaults={'quantity': quantity})
                if not created:
                    item.quantity += quantity
                    item.save()

        return redirect('cart_page')

    # Обработка GET — просто показываем калькулятор
    return render(request, 'calculator.html', {'products': products})


def cart_page(request):
    if not request.user.is_authenticated:
        return redirect('login')

    try:
        cart = Cart.objects.get(user=request.user)
    except Cart.DoesNotExist:
        cart = None

    cart_items = cart.items.all() if cart else []

    context = {
        'cart_items': cart_items,
        'total_price': cart.total_price() if cart else 0
    }
    return render(request, 'cart.html', context)


class NewPageView(View):
    def get(self, request):
        return render(request, "news.html")


class ProductsPageView(View):
    def get(self, request):
        return render(request, "products.html")


class ProfilePageView(View):
    def get(self, request):
        return render(request, "profile.html")


def clear_cart(request):
    if request.method == 'POST':
        if request.user.is_authenticated:
            try:
                cart = Cart.objects.get(user=request.user)
                cart.items.all().delete()
            except Cart.DoesNotExist:
                pass
        else:
            request.session['cart'] = {}
            request.session.modified = True
        return redirect('cart_page')
    else:
        return redirect('cart_page')


def send_order(request):
    if request.method == 'POST':
        first_name = request.POST.get('first_name', '').strip()
        if not first_name:
            return render(request, 'cart.html', {'error': 'Пожалуйста, введите Имя'})
        last_name = request.POST.get('last_name', '').strip()
        if not last_name:
            return render(request, 'cart.html', {'error': 'Пожалуйста, введите Фамилия'})
        phone = request.POST.get('phone', '').strip()
        if not phone:
            return render(request, 'cart.html', {'error': 'Пожалуйста, введите номер телефона'})
        phone_2 = request.POST.get('phone', '').strip()
        if not phone_2:
            return render(request, 'cart.html', {'error': 'Пожалуйста, введите номер телефона'})

        if request.user.is_authenticated:
            try:
                cart = Cart.objects.get(user=request.user)
                items = cart.items.all()
            except Cart.DoesNotExist:
                items = []
        else:
            items = []

        if not items:
            return render(request, 'cart.html', {'error': 'Корзина пуста'})

        # Формируем сообщение для отправки
        message_lines = [f"Имя: {first_name}", f"Фамилия: {last_name}", f"Номер телефона: {phone}", f"Дополнительный номер телефона: {phone}", "Новый заказ:"]
        total = 0
        for item in items:
            line = f"{item.product.product_name} x{item.quantity} = {item.total_price()} so'm"
            message_lines.append(line)
            total += item.total_price()
        message_lines.append(f"Итого: {total} so'm")
        message = "\n".join(message_lines)

        import requests
        token = '7595044895:AAHIipzGqWdoSZCbUzBwWGiV9bDEfoi7KUg'
        chat_id = '6133631269'
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        payload = {
            'chat_id': chat_id,
            'text': message
        }
        requests.post(url, data=payload)

        # Очищаем корзину после заказа
        if request.user.is_authenticated:
            cart.items.all().delete()
        else:
            request.session['cart'] = {}
            request.session.modified = True

        return render(request, 'index.html', {'total': total})

    else:
        return redirect('cart_page')


def login_page_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # куда хочешь после входа
        else:
            error = "Неверное имя пользователя или пароль"
            return render(request, 'login.html', {'error': error})

    return render(request, 'login.html')


def register(request):
    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            login(request, user)
            return redirect('home')  # Заменить на нужную страницу
    else:
        form = RegisterForm()
    return render(request, 'register.html', {'form': form})

TOKEN = '7557922403:AAHJOItETftKkGxr8HUt6f4pxsWJWTi3KJw'
CHAT_ID = '6133631269'


@csrf_protect
def send_form_telegram_message(request):
    if request.method == "POST":
        first_name = request.POST.get('first_name', '')
        last_name = request.POST.get('last_name', '')
        comp_name = request.POST.get('comp_name', '')
        phone1 = request.POST.get('phone1', '')
        phone2 = request.POST.get('phone2', '')
        email = request.POST.get('email', '')
        text = request.POST.get('text', '')

        message = (
            f"Новая заявка:\n"
            f"Имя: {first_name}\n"
            f"Фамилия: {last_name}\n"
            f"Название Компании: {comp_name}\n"
            f"Телефон 1: {phone1}\n"
            f"Телефон 2: {phone2}\n"
            f"Email: {email}\n"
            f"Сообщение: {text}"
        )

        url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
        data = {'chat_id': CHAT_ID, 'text': message}

        r = requests.post(url, data=data)
        try:
            response = r.json()
        except Exception:
            response = r.text

        if r.status_code == 200 and response.get('ok'):
            return redirect('/')
        else:
            return JsonResponse({'status': 'error', 'telegram_response': response})

    return JsonResponse({'status': 'method_not_allowed'}, status=405)