from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('send_message/', views.send_form_telegram_message, name='send_form_telegram_message'),
]
